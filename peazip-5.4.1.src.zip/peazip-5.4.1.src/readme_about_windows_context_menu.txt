Translated system's context menu for PeaZip, works for cascaded context menu entries on W7 or more recent systems.

HOW TO APPLY TRANSLATION TO CONTEXT MENU:
Download the .reg file (Windows registry script) for the desired language, doubleclick and confirm merging the entries in the registry.

HOW TO CONTRIBUTE A NEW TRANSLATION OR MAINTAIN AN EXISTING ONE:
Option 1)
With a plain text editor, translate the quoted texts after the @= sign.
Save the file as ANSI text, or Unicode if extended characters are featured - the text editor software should prompt a message if this condition is applicable.
Option 2)
Translate following text lines:
Add to archive
Add to separate archive(s)
Add to .7Z
Add to .7Z, fastest
Add to .7Z, normal
Add to .7Z, ultra
Add to .ZIP
Add to .ZIP, fastest
Add to .ZIP, normal
Add to .ZIP, ultra
Zip and mail
Add to self-extracting archive
Open as archive
Browse path with PeaZip
Split file
Secure delete
Extract here
Extract here (in new folder)
Extract...
Extract archives
Test archive(s)

You can send the translated script or text lines to giorgio.tani.software@gmail.com to share the translation with the community under LGPL license.